<?php
if (isset($_POST["submit"])) {
    $fname = $_POST['fname'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $subject_list = $_POST['subject_list'];
    $message = $_POST['message'];
    include('conn.php');
    $insertquery = "insert into formdata(fname,mobile,email,subject_list,message) 
    VALUES('$fname','$mobile','$email','$subject_list','$message')";
    mysqli_query($conn, $insertquery);
    $conn->close();


    $to = 'test@techsolvitservice.com';
    $header = "From:Raza <razaintakhab21@gmail.com> \r\n";

    $header .= "MIME-Version: 1.0\r\n";
    $header .= "Content-type: text/html\r\n";
    $msg = '<html>

    <head>
    
    <title>Form Detail</title>
    
    </head>
    
    <body>
    
    <p>Hi admin, check following detail from ' . $fname . '</p>
    
    <table border="1">
    
    <tr>
    
    <th>FUll Name</th><th>Mobile</th><th>Email</th><th>Subject</th><th>message</th>
    
    </tr>
    
    <tr>
    
    <td>' . $fname . '</td>' . $mobile . '<td>' . $email . '</td><td>' . $subject_list . '</td><td>' . $message . '</td>
    
    </tr>
   
    
    </table>
    
    </body>
    
    </html>
    ';
    if (mail($to, $fname, $msg, $header)) {
        echo "form send to mail successfully";
    }



}
?>
<?php
echo "<center><h1>Form Submitted</h1></center>"

    ?>