<?php
$host = 'localhost:3306';
$user = 'root';
$pass = '';
$database = 'contact_form';
$conn = mysqli_connect($host, $user, $pass, $database);
// if (!$conn) {
//     die('Could not connect: ' . mysqli_error());
// }
//  echo 'Connected successfully';
?>